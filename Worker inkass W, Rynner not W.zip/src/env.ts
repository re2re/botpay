export interface Env {
    DB: D1Database;
    MYBROWSER: any;
  
    BOT_TOKEN: string;
    CHAT_MAIN: string;
    CHAT_INKASS: string;
    
    SITE_URL: string;
    SITE_LOGIN: string;
    SITE_PASSWORD: string;

  }
  