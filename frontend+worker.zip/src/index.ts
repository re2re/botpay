import { register } from './register.ts';
import { addTicket } from './tickets.ts';
import { scheduled } from './runner.ts';
import { Env } from './env.ts';
import { notify } from './telegram.ts';

function withCors(response: Response) {
  const newHeaders = new Headers(response.headers);
  newHeaders.set('Access-Control-Allow-Origin', '*');
  newHeaders.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  newHeaders.set('Access-Control-Allow-Headers', 'Content-Type');
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: newHeaders,
  });
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    // обработка OPTIONS для CORS
    if (request.method === 'OPTIONS') {
      return withCors(new Response(null, { status: 204 }));
    }

    if (url.pathname === '/api/terminals' && request.method === 'GET') {
      const { results } = await env.DB
        .prepare('SELECT id, enabled FROM terminals')
        .all();
      return withCors(Response.json(results));
    }

    if (url.pathname === '/api/terminals/add' && request.method === 'POST') {
      try {
        const body = await request.json() as { id: string };
        const id = body.id;
        if (!id) return withCors(Response.json({ ok: false, error: 'MISSING_ID' }, { status: 400 }));

        const exists = await env.DB
          .prepare('SELECT 1 FROM terminals WHERE id = ?')
          .bind(id)
          .first();

        if (exists) {
          return withCors(Response.json({ ok: false, error: 'ID_EXISTS' }, { status: 409 }));
        }

        await env.DB
          .prepare('INSERT INTO terminals (id, enabled) VALUES (?, 1)')
          .bind(id)
          .run();

        return withCors(Response.json({ ok: true }));
      } catch (error) {
        console.error('Ошибка вставки терминала:', error);
        return withCors(Response.json({ ok: false, error: 'INTERNAL_ERROR' }, { status: 500 }));
      }
    }

    if (url.pathname === '/api/terminals/toggle' && request.method === 'POST') {
      const { id } = await request.json();
      await env.DB
        .prepare('UPDATE terminals SET enabled = NOT enabled WHERE id = ?')
        .bind(id)
        .run();
      return withCors(Response.json({ ok: true }));
    }

    if (url.pathname === '/api/terminals/delete' && request.method === 'POST') {
      const { id } = await request.json();
      await env.DB
        .prepare('DELETE FROM terminals WHERE id = ?')
        .bind(id)
        .run();
      return withCors(Response.json({ ok: true }));
    }

    if (url.pathname === '/api/inkass' && request.method === 'POST') {
      const { terminal_id } = await request.json();
      if (!terminal_id) {
        return withCors(Response.json({ ok: false, error: 'MISSING_TERMINAL_ID' }, { status: 400 }));
      }

      await notify(env, `Инкассация на терминале №${terminal_id} — сумма обнулена.`);
      return withCors(Response.json({ ok: true }));
    }

    if (url.pathname === '/api/tickets' && request.method === 'POST') {
      return await addTicket(request, env);
    }

    if (url.pathname === '/api/tickets/new' && request.method === 'GET') {
      const { results } = await env.DB
        .prepare('SELECT id, terminal_id, amount FROM tickets WHERE status = ?')
        .bind('NEW')
        .all();
      return withCors(Response.json(results));
    }

    return withCors(new Response('Not Found', { status: 404 }));
  },

  scheduled,
};