import puppeteer from '@cloudflare/puppeteer';
import { Env } from './env.ts';

export async function scheduled(_e: ScheduledController, env: Env) {
  const { results } = await env.DB
    .prepare(
      `UPDATE tickets SET status='PROCESSING'
       WHERE id = (SELECT id FROM tickets WHERE status='NEW' LIMIT 1)
       RETURNING *`
    )
    .run();

  if (!results?.length) return;
  const t = results[0];
  const pin = String(t.pin).padStart(10, '0');
  let status = 'FAIL_ATTEMPTS';

  const browser = await puppeteer.launch(env.MYBROWSER);
  try {
    const page = await browser.newPage();
    page.setDefaultTimeout(20000);

    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        await page.goto(env.SITE_URL, { waitUntil: 'networkidle0', timeout: 60000 });

        await page.waitForSelector('input[placeholder="Введите Ваш логин"]', { timeout: 20000 });
        await page.type('input[placeholder="Введите Ваш логин"]', env.SITE_LOGIN);
        await page.type('input[placeholder="Введите Ваш пароль"]', env.SITE_PASSWORD);
        await page.click('button.btn.btn-red');

        const svgCard = await page.waitForSelector('svg[data-icon="credit-card"]', { timeout: 20000 });
        await (await svgCard.evaluateHandle(el => el.closest('button'))).click();

        await page.$$eval('div.e-tab-text', els => {
          const el = els.find(e => e.textContent?.trim() === 'Пополнение');
          if (el) (el as HTMLElement).click();
        });

        await page.waitForSelector('input[aria-label="textbox"]', { timeout: 10000 });
        await page.type('input[aria-label="textbox"]', pin);

        await page.click('input.e-numerictextbox', { clickCount: 3 });
        await page.keyboard.press('Delete');
        await page.type('input.e-numerictextbox', String(t.amount));

        await page.$$eval('button.btn-red', els => {
          const el = els.find(e => e.textContent?.includes('Пополнить'));
          if (el) (el as HTMLElement).click();
        });

        const popup = await page.waitForSelector('p.text-justify', { timeout: 25000 });
        const text = await popup.evaluate(el => el.textContent ?? '');

        if (!text.includes('зачислено')) throw new Error('popup mismatch');

        await page.$$eval('button.btn-red', els => {
          const el = els.find(e => e.textContent?.includes('Закрыть'));
          if (el) (el as HTMLElement).click();
        });

        const svgOut = await page.waitForSelector('svg[data-icon="right-from-bracket"]', { timeout: 10000 });
        await (await svgOut.evaluateHandle(el => el.closest('button'))).click();

        status = 'SUCCESS';
        break;
      } catch (err) {
        if (attempt < 3) {
          await page.waitForTimeout(30000); // пауза между попытками
        }
      }
    }
  } finally {
    await browser.close();
  }

  await env.DB.prepare('DELETE FROM tickets WHERE id=?').bind(t.id).run();
}
