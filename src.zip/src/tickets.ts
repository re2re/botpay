import { Env } from './env.ts';

export async function addTicket(req: Request, env: Env): Promise<Response> {
  const { terminal_id, pin, amount } = await req.json();

  if (!terminal_id || typeof pin !== 'string' || !/^\d{10}$/.test(pin) || typeof amount !== 'number') {
    return new Response(
      JSON.stringify({ ok: false, error: 'BAD_REQUEST' }),
      { status: 400 }
    );
  }

  const terminal = await env.DB
    .prepare('SELECT id FROM terminals WHERE id = ?')
    .bind(terminal_id)
    .first();

  if (!terminal) {
    return new Response(
      JSON.stringify({ ok: false, error: 'TERMINAL_NOT_FOUND' }),
      { status: 404 }
    );
  }

  await env.DB
    .prepare(
      'INSERT INTO tickets (pin, amount, terminal_id, status) VALUES (?, ?, ?, ?)'
    )
    .bind(pin, amount, terminal_id, 'NEW')
    .run();

  return new Response(JSON.stringify({ ok: true }), { status: 202 });
}
