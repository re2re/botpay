import { Env } from './env.ts';

export async function notify(env: Env, text: string) {
  await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ chat_id: env.CHAT_MAIN, text }),
  });
}
