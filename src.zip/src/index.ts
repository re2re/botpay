import { register } from './register.ts';
import { addTicket } from './tickets.ts';
import { authorizeTerminal } from './terminals.ts';
import { scheduled } from './runner.ts';
import { Env } from './env.ts';
import { notify } from './telegram.ts';

function handleCors(handler: any) {
  return async (req: Request, env: Env, ctx: ExecutionContext) => {
    const resp = await handler(req, env, ctx);
    const headers = new Headers(resp.headers);
    headers.set('Access-Control-Allow-Origin', '*');
    headers.set('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    headers.set('Access-Control-Allow-Headers', 'Content-Type');
    return new Response(resp.body, {
      status: resp.status,
      headers,
    });
  };
}

export default {
  fetch: handleCors(async (req: Request, env: Env, ctx: ExecutionContext) => {
    const url = new URL(req.url);

    if (req.method === 'OPTIONS') {
      return new Response('ok', { status: 200 });
    }

    if (url.pathname === '/tickets' && req.method === 'POST') {
      return addTicket(req, env);
    }

    if (url.pathname === '/register' && req.method === 'POST') {
      return register(req, env);
    }

    if (url.pathname === '/api/terminals/auth' && req.method === 'POST') {
      return authorizeTerminal(req, env);
    }

    if (url.pathname === '/terminals/status' && req.method === 'GET') {
      const id = url.searchParams.get('id');
      if (!id) return new Response('missing id', { status: 400 });

      const result = await env.DB.prepare('SELECT enabled FROM terminals WHERE id = ?')
        .bind(Number(id))
        .first();

      if (!result) {
        return new Response('not found', { status: 404 });
      }

      return new Response(JSON.stringify({ enabled: result.enabled }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    if (url.pathname === '/admin/notify' && req.method === 'POST') {
      return notify(req, env);
    }

    return new Response('Not found', { status: 404 });
  }),

  scheduled,
};