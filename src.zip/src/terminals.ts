export async function authorizeTerminal(req: Request, env: Env): Promise<Response> {
  try {
    const { terminal_id } = await req.json();

    if (typeof terminal_id !== "number") {
      return new Response(JSON.stringify({ ok: false, error: "INVALID_ID" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }

    const result = await env.DB.prepare("SELECT id FROM terminals WHERE id = ?")
      .bind(terminal_id)
      .first();

    if (!result) {
      return new Response(JSON.stringify({ ok: false, error: "NOT_FOUND" }), {
        status: 404,
        headers: { "Content-Type": "application/json" }
      });
    }

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: "SERVER_ERROR" }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
}

  